let numero;
let media = 0;
let numero1;
let numero2;
let numero3;
let numero4;
let numero5;
let numero6;
let numero7;
let numero8;
let numero9;
let numero10;

do {
  numero = prompt("Introduce un numero entero (o bien . para finalizar): ");
  media += numero;
} while (numero <= 10 && numero != ".");

alert("La media es: " + media);

if (numero1 * 2 > media) {
  alert();
}

switch (key) {
  case value:
    break;

  default:
    break;
}
